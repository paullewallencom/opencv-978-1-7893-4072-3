This directory contains material supporting chapter 3 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

Files:
	colordetector.h
	colordetector.cpp
	colorDetection.cpp
corresponds to Recipe:
Using the Strategy Pattern in Algorithm Design

File:
	extractObject.cpp
correspond to Recipe:
Segmenting an image with the GrabCut algorithm  

File:
	huesaturation.cpp
correspond to Recipe:
Representing colors with hue, saturation and brightness

You need the images:
boldt.jpg
girl.jpg
